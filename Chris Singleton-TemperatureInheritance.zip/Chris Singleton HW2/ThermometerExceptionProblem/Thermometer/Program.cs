﻿/*******************************************************************************************
 * Class: Programming 120  (Classes and Objects)                                           *
 * Project: HW2 Thermometer                                                                *
 * Professor: Kurt Friedrich                                                               *
 * Name: Chris Singleton                                                                   *
 * Date: 10/01/2016                                                                        *
 *******************************************************************************************
 * Summary: 1. User inputs a number and the string changes values in the console.          *
 *          2. Console application references the library solution for temperature state.  *
 *          3. Methods convert to double and calculate temperature while passing as string.*
 *          4. Static fields are private so only what is in the library can reference.     *
 *          5. To convert to double, a method is called directly.                          *
 ******************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

namespace Thermometer
{
    class Program
    {
        static void Main(string[] args)
        {
            //Write a test class that creates an instance of a thermometer, 
            // displays the current Celsius and Fahrenheit temperature.

            Console.WriteLine("This is a test of the Thermometer Class");
            Console.WriteLine();

            // Set 1 c = 0, f = 32
            Console.WriteLine("The current temp in C is: {0}", ThermometerClass.CelsiusTemperature);
            Console.WriteLine("The current temp in F is: {0}", ThermometerClass.FahrenheitTemperature);

            Console.WriteLine();

            // adds 50 degrees Celsius to it and then displays the Celsius and Fahrenheit temperature.
            ThermometerClass.AddCelsius("50"); 
            // Set 2 c = 50, f = 122
            Console.WriteLine("The current temp in C is: {0}", ThermometerClass.CelsiusTemperature);
            Console.WriteLine("The current temp in F is: {0}",  ThermometerClass.FahrenheitTemperature);

            Console.WriteLine();

            // subtracts 25 degrees Celsius to it and then displays the Celsius and Fahrenheit temperature.
            ThermometerClass.AddFahrenheit("-25"); // 122 -25 = 97f
            // Set 3 c = 36.11111111, f = 97 
            Console.WriteLine("The current temp in C is: {0}", ThermometerClass.CelsiusTemperature);
            Console.WriteLine("The current temp in F is: {0}", ThermometerClass.FahrenheitTemperature);

            Console.WriteLine();

            // now the user can change the value
            Console.Write("Enter a Celsius value to change the temperature by: ");
            try
            {
                ThermometerClass.AddCelsius(Console.ReadLine());
                Console.WriteLine("The current temp in C is: {0}", ThermometerClass.CelsiusTemperature);
                Console.WriteLine("The current temp in F is: {0}", ThermometerClass.FahrenheitTemperature);
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine("That was not a valid temperature. \nThe temperature setting was not changed.");
                Console.WriteLine("The current temp is: {0}\u00B0C \nThe current temp is: {1}\u00B0F", ThermometerClass.CelsiusTemperature, ThermometerClass.FahrenheitTemperature);
            }

            {
                throw new ApplicationException("That was not a valid temperature.");
            }
        }
    }
}
